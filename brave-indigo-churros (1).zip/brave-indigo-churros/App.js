import { View, Text, Image, StyleSheet } from 'react-native';

export default function App() {
  const fullName = 'Rulan Zhexen';
  const profession = 'CS-401 Student';
  const description =
    'Computer science student interested in mobile application development and modern technologies. Motivated to learn and improve programming skills.';

  const phone = '87473011016';
  const city = 'Pavlodar, KZ';

  return (
    <View style={styles.screen}>
      <View style={styles.card}>
        <Image
          style={styles.avatar}
          source={{ uri: 'https://ui-avatars.com/api/?name=Rulan+Zhexen&size=256&background=0D8ABC&color=fff' }}
        />

        <Text style={styles.name}>{fullName}</Text>
        <Text style={styles.profession}>{profession}</Text>
        <Text style={styles.description}>{description}</Text>
      </View>

      <View style={styles.contacts}>
        <Text style={styles.contactText}>📞 {phone}</Text>
        <Text style={styles.contactText}>📍 {city}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#eaf0f6',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  card: {
    width: '100%',
    maxWidth: 320,
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    elevation: 5,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  profession: {
    fontSize: 16,
    color: '#666',
    marginBottom: 12,
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    color: '#444',
  },
  contacts: {
    alignItems: 'center',
  },
  contactText: {
    fontSize: 14,
    marginVertical: 2,
  },
});
